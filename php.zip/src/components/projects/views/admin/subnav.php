

<ul class="subnav">
    <li><a href="/admin/projects/0/20">List All Addresses</a></li>
    <li><a href="/admin/projects/0">Create New Address</a></li>
</ul>