$( document ).ready(function() {
    $('#editor').wysiwyg();

});
