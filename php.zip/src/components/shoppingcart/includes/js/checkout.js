$( document ).ready(function() {
    
    $("#confirmBuyerInfo").click(function(){        
        $("#confirmBuyerForm").submit();        
    });
    
});