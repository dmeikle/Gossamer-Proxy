<?php

return array (
    'LABEL_SALES_LIST' => 'Sales List',
    'BUTTON_VIEW' => 'View',
    'BUTTON_DELETE' => 'Delete',
    'LABEL_PURCHASE_ID' => 'Purchase ID',
    'LABEL_CUSTOMER_NAME' => 'Customer Name',
    'LABEL_EMAIL' => 'Email',
    'LABEL_PURCHASE_DATE' => 'Purchase Date',
    'LABEL_STATUS' => 'Status',
    'LABEL_ACTION' => 'Action' 
);