<?php

return array (
    'NAV_HOME' => 'Home',
    'NAV_CATEGORIES' => 'Categories',
    'NAV_PRODUCTS' => 'Products',
    'NAV_SALES' => 'Sales',
    'NAV_VARIANTS' => 'Variants',
    'NAV_LOCALES' => 'Languages',
    'nav_test' => 'test'
    
);