<?php

return array (
    'LABEL_VOLUME_DISCOUNTS' => 'Volume Discounts',
    'LABEL_QUANTITY' => 'Quantity',
    'LABEL_DISCOUNT_PRICE' => 'Discounted Price',
    'BUTTON_CANCEL' => 'Cancel',
    'BUTTON_SAVE' => 'Save',
    'BUTTON_ADD_ROW' => 'Add New Row'
    
);