<?php

return array (
    'LABEL_PARENT' => 'Parent',
    'LABEL_CATEGORY' => 'Category',
    'LABEL_PICTURE' => 'Picture',
    'LABEL_ADD_EDIT_CATEGORY' => 'Add/Edit Category',
    'OPTION_PARENT_CATEGORY' => 'This is a parent category',
    'BUTTON_SAVE' => 'Save',
    'BUTTON_CANCEL' => 'Cancel',
    'LABEL_CATEGORIES_LIST' => 'Categories List',
    'BUTTON_EDIT' => 'Edit',
    'BUTTON_DELETE' => 'Delete',
    'BUTTON_NEW' => 'Create New Category',
    'LABEL_ACTION' => 'Action'
);