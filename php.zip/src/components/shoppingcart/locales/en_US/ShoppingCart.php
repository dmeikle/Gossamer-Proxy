<?php

return array(
    'BTN_ADD_TO_CART' => 'Add To Cart',
    'BTN_REMOVE_FROM_CART' => 'Remove',
    'NAV_CONTINUE_SHOPPING' => 'Continue Shopping',
    'NAV_GO_TO_CHECKOUT' => 'Go To Checkout'
);