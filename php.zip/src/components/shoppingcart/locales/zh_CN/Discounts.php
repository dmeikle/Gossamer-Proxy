<?php

return array (
    'LABEL_VOLUME_DISCOUNTS' => '批量折扣', 
     'LABEL_QUANTITY' => '数量', 
     'LABEL_DISCOUNT_PRICE' => '优惠价', 
     'BUTTON_CANCEL' => '取消', 
     'BUTTON_SAVE' => '保存', 
     'BUTTON_ADD_ROW' => '添加新行'
    
);