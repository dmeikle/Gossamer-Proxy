<?php

return array (
    'LABEL_PARENT' =>'父',
    'LABEL_CATEGORY' => '分类',
     'LABEL_PICTURE' => '图片',
     'LABEL_ADD_EDIT_CATEGORY' => '添加/编辑类别',
     'OPTION_PARENT_CATEGORY' => '这是一个父类',
     'BUTTON_SAVE' => '保存',
     'BUTTON_CANCEL' => '取消',
     'LABEL_CATEGORIES_LIST' => '分类目录',
     'BUTTON_EDIT' => '编辑',
     'BUTTON_DELETE' => '删除',
     'BUTTON_NEW' => '创建新的分类',
     'LABEL_ACTION' => '动作'
);