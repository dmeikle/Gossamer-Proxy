<?php

return array (
    'LABEL_SALES_LIST'=>'销售清单', 
    'BUTTON_VIEW'=>'查看', 
    'BUTTON_DELETE'=>'删除', 
    'LABEL_PURCHASE_ID'=>'购买的ID', 
    'LABEL_CUSTOMER_NAME'=>'客户名称', 
    'LABEL_EMAIL'=>'电子邮件', 
    'LABEL_PURCHASE_DATE'=>'购买日期', 
    'LABEL_STATUS'=>'状态', 
    'LABEL_ACTION'=>'动作'
);