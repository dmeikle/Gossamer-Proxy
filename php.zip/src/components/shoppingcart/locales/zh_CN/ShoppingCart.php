<?php

return array(
    'BTN_ADD_TO_CART' => 'CHineseAdd To Cart'
);