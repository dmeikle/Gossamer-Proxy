<?php

return array (
    'NAV_HOME' => '家',
    'NAV_CATEGORIES' => '分类',
    'NAV_PRODUCTS' => '产品',
    'NAV_SALES' => '销售',
    'NAV_VARIANTS' => '变种',
    'NAV_LOCALES' => '语言'
);