<?php

return array (
    'LABEL_PARENT' => 'Mère',
    'LABEL_CATEGORY' => 'Catégorie',
    'LABEL_PICTURE' => 'Image',
    'LABEL_ADD_EDIT_CATEGORY' => 'Ajouter / Modifier Catégorie',
    'OPTION_PARENT_CATEGORY' => 'Il s`agit d`une catégorie parente',
    'BUTTON_SAVE' => 'Sauver',
    'BUTTON_CANCEL' => 'Annuler',
    'LABEL_CATEGORIES_LIST' => 'Liste des Catégories',
    'BUTTON_EDIT' => 'Modifier',
    'BUTTON_DELETE' => 'Effacer',
    'BUTTON_NEW' => 'Nouveau' ,
    'LABEL_ACTION' => 'Action'   
);