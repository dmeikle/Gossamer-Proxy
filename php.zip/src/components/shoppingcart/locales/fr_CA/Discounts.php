<?php

return array (
    'LABEL_VOLUME_DISCOUNTS' => 'Escomptes de Volume',
    'LABEL_QUANTITY' => 'Quantity',
    'LABEL_DISCOUNT_PRICE' => 'Prix Réduit',
    'BUTTON_CANCEL' => 'Cancel',
    'BUTTON_SAVE' => 'Sauver',
    'BUTTON_ADD_ROW' => 'Ajouter une Nouvelle Ligne'
    
);