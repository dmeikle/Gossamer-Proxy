<?php

return array (
    'LABEL_SALES_LIST' => 'La Liste des Ventes',
    'BUTTON_VIEW' => 'Examiner',
    'BUTTON_DELETE' => 'Effacer',
    'LABEL_PURCHASE_ID' => 'Achat ID',
    'LABEL_CUSTOMER_NAME' => 'Le Nom du Client',
    'LABEL_EMAIL' => 'Email',
    'LABEL_PURCHASE_DATE' => 'Date Pruchase',
    'LABEL_STATUS' => 'Statut',
    'LABEL_ACTION' => 'Action' 
);