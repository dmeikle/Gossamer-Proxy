<?php

return array (
    'NAV_HOME' => 'd`accueil',
    'NAV_CATEGORIES' => 'Catégories',
    'NAV_PRODUCTS' => 'Produits',
    'NAV_SALES' => 'Ventes',
    'NAV_VARIANTS' => 'Variantes',
    'NAV_LOCALES' => 'langues'
);