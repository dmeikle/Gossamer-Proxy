<?php

return array(
    'BTN_ADD_TO_CART' => 'Add To Cart'
);