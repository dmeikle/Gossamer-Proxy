
<form method="post" role="form">
    <table class="table">
      <tr>
        <td>Section:</th>
        <td><?php echo $form['section']; ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><?php echo $form['submit']; ?></td>
      </tr>
    </table>
</form>