<ul class="subnav">
    <li><a href="/admin/incidents/0/20">list all incidents</a></li>
    <li><a href="/admin/incidents/type/0/20">list all incident types</a></li>
    <li><a href="/admin/incidents/type/0">create new incident type</a></li>
    <li><a href="/admin/incidents/sections/0/20">list all sections</a></li>
    <li><a href="/admin/incidents/sections/0">create new section</a></li>
</ul>