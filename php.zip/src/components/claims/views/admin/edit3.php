<form class="form-standard" role="form">
    <h2 class="form-signin-heading">new claim form - additional details</h2>
    <table class="table">
        <tr>
            <td>Contact info:</td>
            <td><textarea class="form-control" rows="3"></textarea></td>
        </tr>
            <tr>
            <td>Notes:</td>
            <td><textarea class="form-control" rows="7"></textarea></td>
        </tr>
    </table>
    <input type="hidden" name="attendingTechnicians[]" id="attendingTechnicians" />
    <button class="btn btn-lg btn-primary btn-block" type="submit">Next</button>
</form>