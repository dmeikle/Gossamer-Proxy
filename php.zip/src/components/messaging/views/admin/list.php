

<?php $Messages = array(); ?>

<table class="table table-striped table-hover">
  <tr>
    <th scope="col">From</th>
    <th scope="col">To</th>
    <th scope="col">Send Date</th>
    <th scope="col">View Date</th>
    <th scope="col">Message Type</th>
    <th scope="col">Action</th>
  </tr>
  <?php foreach($Messages as $message) {?>
  <tr>
    <td></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <?php } ?>
</table>