<?php

return array (
    'PAGE_CONTENT' => '<p style="margin:20px 10px 0px 50px">
我们欢迎您与我们联系，您可以向我们提出任何问题，或只是打个招呼认识一下。 <br>请写email至:
info@glenmeikle.com<br>
<br>
目前我们的产品仅出售亚洲，不久的将来，产品将会远销太平洋彼岸的北美。<br></p>'
);