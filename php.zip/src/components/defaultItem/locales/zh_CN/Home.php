<?php

return array(
    'section1' => '东方墙壁艺术收藏',
    'section2' => '我热爱设计，创造，建设美丽的东西。'
);