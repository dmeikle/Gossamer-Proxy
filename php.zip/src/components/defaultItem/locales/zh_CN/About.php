<?php

return array(
    'TITLE_ABOUT' => '艺术家简介',
    'TEXT_ABOUT_HEADING' => '嗨，我是Glen Meikle。我热爱设计，创造，建设美丽的东西。'
);