<?php

return array(
    'section1' => 'Oriental Wall Art Collection',
    'section2' => 'Hello! I\'m Glen Meikle and I\'m passionate about designing, creating, and building beautiful things. '
);