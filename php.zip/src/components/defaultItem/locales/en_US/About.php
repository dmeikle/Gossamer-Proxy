<?php

return array(
    'TITLE_ABOUT' => 'About Glen Meikle',
    'TEXT_ABOUT_HEADING' => 'Hello! I\'m Glen Meikle and I\'m passionate about designing, creating, and building beautiful things.'
);