<?php

return array (
    'PAGE_CONTENT' => '<p style="margin:20px 10px 0px 50px">
We welcome you to contact us and ask us any questions or just say hi<br>
             </p>'
);