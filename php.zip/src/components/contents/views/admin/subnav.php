<ul class="subnav">
    <li>
        <a href="/admin/contents/jobs/0/20">List All Jobs</a>
    </li>
    <li>
        <a href="/admin/contents/jobs/0">Create New Job</a>
    </li>
    <li><!-- '3' is the id for scheduling -->
        <a href="/admin/contents/scheduling/3/0/20">Scheduling</a>
    </li>
</ul>