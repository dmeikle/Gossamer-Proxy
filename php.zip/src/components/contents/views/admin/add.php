<table class="table">
  <tr>
      <td>Claim ID</td>
      <td><input type="text" class="form-control" name="textfield" id="textfield" placeholder="autocomplete search field"></td>
  </tr>
  <tr>
    <td>Location</td>
    <td><select class="form-control" name="select" id="select">
            <option>populates based on claim ID</option>
    </select></td>
  </tr>
  <tr>
    <td>Processing Type</td>
    <td><select class="form-control" name="select2" id="select2">
            <option>processing type</option>
    </select></td>
  </tr>
  <tr>
    <td>Date</td>
    <td><input class="form-control" type="text" name="textfield4" id="textfield4"></td>
  </tr>
  <tr>
    <td>Supervisor</td>
    <td>
        <select class="form-control">
            <option>employee 1</option>
            <option>employee 2</option>
        </select>
        
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><button>Save</button> <button>Cancel</button></td>
  </tr>
</table>