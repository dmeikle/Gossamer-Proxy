notes on scoping tables:

