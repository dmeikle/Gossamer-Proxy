
<script language="javascript">

$(document).ready(function() {
    $('.edit').click(function() {
        window.location = '/admin/scoping/' + $(this).data('id');
    })
});

</script>


<table class="table">
  <tr>
      <td colspan="2">
          <div style="float:right; margin-top: 20px"><button class="edit" data-id="1">edit</button></div>
          <h3>Bedroom 1 - 101</h3></td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td colspan="2">
          <div style="float:right; margin-top: 20px"><button>edit</button></div>
          <h3>Kitchen - 102</h3></td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td colspan="2">
          <div style="float:right; margin-top: 20px"><button>edit</button></div>
          <h3>Living Room - 103</h3></td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
  <tr>
    <td> remove chair rail (T.F.W.) &amp; finish to preloss </td>
    <td> 12 LF </td>
  </tr>
</table>
