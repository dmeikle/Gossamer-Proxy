<ul class="subnav">
 
    <li>
        <a href="/admin/scoping/requests/0/20">List All Requests</a>
    </li>
    <li>
        <a href="/admin/scoping/requests/0">Create New Request</a>
    </li>
    <li>
        <a href="/admin/scoping/takeoffs/0/20">List All Takeoffs</a>
    </li>
    <li>
        <a href="/admin/surveys/scopeforms/0/20">List Forms</a>
    </li>
    <li>
        <a href="/admin/surveys/sheetquestions/0/20">List Questions</a>
    </li>
    <li>
        <a href="/admin/surveys/sheetanswers/0/20">List Answers</a>
    </li>
    
</ul>