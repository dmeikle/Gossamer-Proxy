<ul class="subnav">
    <li><a href="/admin/reminders/0/20">List All</a></li>
    <li><a href="/admin/reminders/0">Add New Reminder</a></li>
</ul>