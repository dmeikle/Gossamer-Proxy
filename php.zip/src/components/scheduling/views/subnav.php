<ul class="subnav">
    <li>
        <a href="/admin/scheduling/compressed/1/20141015">Compressed View</a>
    </li>
    <li>
        <a href="/admin/scheduling/chart/1/20141015">Chart View</a>
    </li>
    <li>
        <a href="/admin/scheduling/calendar/1/20141015">Calendar View</a>
    </li>
</ul>