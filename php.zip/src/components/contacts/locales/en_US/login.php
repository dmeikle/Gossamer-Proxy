<?php

return array(
        'LOGIN_FORM' => 'Login Form',
	'LOGIN_EMAIL' => 'Email',
	'LOGIN_EMAIL_PROMPT' => 'enter your email address',
	'LOGIN_PASSWORD' => 'Password',
	'LOGIN_PASSWORD_PROMPT' => 'enter your password',
	'LOGIN_LOST_PASSWORD' => 'I forgot my password',
	'LOGIN_SIGNIN' => 'Sign In',
	'LOGIN_NEW' => 'New?',
	'LOGIN_SIGNUP' => 'Sign Up',
	'LOGIN_STAY_LOGGED_IN' => 'Keep me logged in for the day'
);