
<ul class="subnav">
    <li>
        <a href="/admin/cms/pages/0/20">List All Pages</a>
    </li>
    <li>
        <a href="/admin/cms/pages/0">Create New Page</a>
    </li>
    <li>
        <a href="/admin/cms/sections/0/20">List All Sections</a>
    </li>
    <li>
        <a href="/admin/blogs/0/20">List All Blogs</a>
    </li>
    <li>
        <a href="/admin/blogs/0">Create New Blog</a>
    </li>
 
</ul>