
this page needs styling...in core<br><br>

<?php


$page = current($CmsPage);
$locale = $this->getDefaultLocale();

echo $page['content'];

?>