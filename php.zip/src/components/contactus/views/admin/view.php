<table class="table">
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_NAME');?>
        </td>
        <td>
            <?php echo $form['name']; ?>
        </td>
    </tr>
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_EMAIL');?>
        </td>
        <td>
            <?php echo $form['email']; ?>
        </td>
    </tr>
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_TELEPHONE');?>
        </td>
        <td>
            <?php echo $form['telephone']; ?>
        </td>
    </tr>
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_COMPANY');?>
        </td>
        <td>
            <?php echo $form['company']; ?>
        </td>
    </tr>
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_SUBJECT');?>
        </td>
        <td>
            <?php echo $form['subject']; ?>
        </td>
    </tr>
    <tr>
        <td>
            <?php echo $this->getString('CONTACTUS_COMMENTS');?>
        </td>
        <td>
            <?php echo $form['comments']; ?>
        </td>
    </tr>
    <tr>
        <td>
           
        </td>
        <td>
            <?php //echo $form['submit']; ?> 
        </td>
    </tr>
</table>