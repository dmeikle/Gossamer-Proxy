<table class="table">
  <tr>
    <th scope="col">Job #</th>
    <th scope="col">Status</th>
    <th scope="col">Active</th>
    <th scope="col">Address</th>
    <th scope="col">Authorize Date</th>
    <th scope="col">Supervisor</th>
  </tr>
  <tr>
    <td>MV-14JS123</td>
    <td>on-hold</td>
    <td>false</td>
    <td>1234 University Place, Surrey, BC</td>
    <td>2014-10-12</td>
    <td>Marlo</td>
  </tr>
  <tr>
    <td>MV-14JS123</td>
    <td>repair</td>
    <td>false</td>
    <td>2014-10-10</td>
    <td>2014-10-12</td>
    <td>Joseph</td>
  </tr>
  <tr>
    <td>MV-14JS123</td>
    <td>addedndum</td>
    <td>false</td>
    <td>2014-10-10</td>
    <td>2014-10-12</td>
    <td>Marlo</td>
  </tr>
  <tr>
    <td>MV-14JS123</td>
    <td>completed</td>
    <td>false</td>
    <td>2014-10-10</td>
    <td>2014-10-12</td>
    <td>Joseph</td>
  </tr>
  <tr>
    <td>MV-14JS123</td>
    <td>&nbsp;</td>
    <td>false</td>
    <td>2014-10-10</td>
    <td>2014-10-12</td>
    <td>Joseph</td>
  </tr>
</table>