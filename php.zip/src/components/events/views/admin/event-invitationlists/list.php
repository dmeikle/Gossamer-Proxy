currently listing all lists without checking which ones are added to this event
 until we determine GUI

<?php

pr($EventInviteLists);
?>