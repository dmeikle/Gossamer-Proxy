
<script language="javascript">
$(function() {
    $( "#addStaff" ).click(function(e) {
        window.location.replace(window.location + "/add");
    });
  });
</script>
<br />
<form role="form">
<table class="table table-bordered table-condensed">
    <thead>
        <tr>
            <th width="14%">
               Sunday
            </th>
            <th width="14%">
                Monday
            </th>
            <th width="14%">
                Tuesday
            </th>
            <th width="14%">
                Wednesday
            </th>
            <th width="14%">
                Thursday
            </th>
            <th width="14%">
                Friday
            </th>
            <th width="14%">
                Saturday
            </th>
        </tr>
    </thead>

<tr>
    <td height="19">
        Aug 31
    </td>
    <td>
       Sep 1
    </td>
    <td>
       2
    </td>
    <td>
        3
    </td>
    <td>
       4
    </td>
    <td>
       5
    </td>
    <td>
        6
    </td>
</tr>
<tr>
  <td colspan="6" align="center"><button  class="btn-xs btn alert-success btn-block">Rick</button></td>
  <td><button  class="btn-xs btn alert-success btn-block">Gil / Ken</button></td>
</tr>
<tr>
    <td><button  class="btn-xs btn alert-warning btn-block">Loree, Sandra, Mike</button></td>
    <td colspan="5" align="center">
      <button  class="btn-xs btn alert-warning btn-block">Jaims on-call p.m.</button></td>
    <td>
      <button  class="btn-xs btn alert-warning btn-block">Manda, Sue, Nic</button></td>
</tr>





<tr>
  <td><button  class="btn-xs btn alert-info btn-block">Rick until 12:00pm</button></td>
  <td>0</td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Matt/Ken/Richard</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren,Marna</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren/Tracy/Richard</button></td>
  <td colspan="2"><button  class="btn-xs btn alert-info btn-block">Kevin</button></td>
  </tr>
<tr>
  <td colspan="7" style="border-bottom: solid 1px black"></td>
  </tr>
<tr>
  <td><strong>
    7
    </strong></td>
  <td><strong>
    8
    </strong></td>
  <td><strong>
    9
    </strong></td>
  <td><strong>
    10
    </strong></td>
  <td><strong>
    11
    </strong></td>
  <td><strong>
    12
    </strong></td>
  <td><strong>
    13
    </strong></td>
</tr>
<tr>
  <td colspan="6" align="center"><button  class="btn-xs btn alert-success btn-block">Rick</button></td>
  <td><button  class="btn-xs btn alert-success btn-block">Gil / Ken</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-warning btn-block">Loree, Sandra, Mike</button></td>
  <td colspan="5" align="center"><button  class="btn-xs btn alert-warning btn-block">Jaims on-call p.m.</button></td>
  <td><button  class="btn-xs btn alert-warning btn-block">Manda, Sue, Nic</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-info btn-block">Rick until 12:00pm</button></td>
  <td><button  class="btn-xs btn alert-info btn-block">0</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Matt/Ken/Richard</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren,Marna</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren/Tracy/Richard</button></td>
  <td colspan="2"><button  class="btn-xs btn alert-info btn-block">Kevin</button></td>
</tr>
<tr>
  <td colspan="7" style="border-bottom: solid 1px black"></td>
  </tr>
<tr>
  <td><strong>
    14
    </strong></td>
  <td><strong>
    15
    </strong></td>
  <td><strong>
    16
    </strong></td>
  <td><strong>
    17
    </strong></td>
  <td><strong>
    18
    </strong></td>
  <td><strong>
    19
    </strong></td>
  <td><strong>
    20
    </strong></td>
</tr>
<tr>
  <td colspan="6" align="center"><button  class="btn-xs btn alert-success btn-block">Rick</button></td>
  <td><button  class="btn-xs btn alert-success btn-block">Gil / Ken</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-warning btn-block">Loree, Sandra, Mike</button></td>
  <td colspan="5" align="center"><button  class="btn-xs btn alert-warning btn-block">Jaims on-call p.m.</button></td>
  <td><button  class="btn-xs btn alert-warning btn-block">Manda, Sue, Nic</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-info btn-block">Rick until 12:00pm</button></td>
  <td><button  class="btn-xs btn alert-info btn-block">0</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Matt/Ken/Richard</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren,Marna</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren/Tracy/Richard</button></td>
  <td colspan="2"><button  class="btn-xs btn alert-info btn-block">Kevin</button></td>
</tr>
<tr>
  <td colspan="7" style="border-bottom: solid 1px black"></td>
  </tr>
<tr>
  <td><strong>
    21
    </strong></td>
  <td><strong>
    22
    </strong></td>
  <td><strong>
    23
    </strong></td>
  <td><strong>
    24
    </strong></td>
  <td><strong>
    25
    </strong></td>
  <td><strong>
    26
    </strong></td>
  <td><strong>
    27
    </strong></td>
</tr>
<tr>
  <td colspan="6" align="center"><button  class="btn-xs btn alert-success btn-block">Rick</button></td>
  <td><button  class="btn-xs btn alert-success btn-block">Gil / Ken</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-warning btn-block">Loree, Sandra, Mike</button></td>
  <td colspan="5" align="center"><button  class="btn-xs btn alert-warning btn-block">Jaims on-call p.m.</button></td>
  <td><button  class="btn-xs btn alert-warning btn-block">Manda, Sue, Nic</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-info btn-block">Rick until 12:00pm</button></td>
  <td><button  class="btn-xs btn alert-info btn-block">0</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Matt/Ken/Richard</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren,Marna</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren/Tracy/Richard</button></td>
  <td colspan="2"><button  class="btn-xs btn alert-info btn-block">Kevin</button></td>
</tr>
<tr>
  <td colspan="7" style="border-bottom: solid 1px black"></td>
  </tr>
<tr>
  <td><strong>
    28
    </strong></td>
  <td><strong>
    29
    </strong></td>
  <td><strong>
    30
    </strong></td>
  <td><strong>
    oct 1
    </strong></td>
  <td><strong>
    2
    </strong></td>
  <td><strong>
    3
    </strong></td>
  <td><strong>
    4
    </strong></td>
</tr>
<tr>
  <td colspan="6" align="center"><button  class="btn-xs btn alert-success btn-block">Rick</button></td>
  <td><button  class="btn-xs btn alert-success btn-block">Gil / Ken</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-warning btn-block">Loree, Sandra, Mike</button></td>
  <td colspan="5" align="center"><button  class="btn-xs btn alert-warning btn-block">Jaims on-call p.m.</button></td>
  <td><button  class="btn-xs btn alert-warning btn-block">Manda, Sue, Nic</button></td>
</tr>
<tr>
  <td><button  class="btn-xs btn alert-info btn-block">Rick until 12:00pm</button></td>
  <td><button  class="btn-xs btn alert-info btn-block">0</td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Matt/Ken/Richard</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren,Marna</button></td>
  <td align="center"><button  class="btn-xs btn alert-info btn-block">Darren/Tracy/Richard</button></td>
  <td colspan="2"><button  class="btn-xs btn alert-info btn-block">Kevin</button></td>
</tr>
</table>
</form>