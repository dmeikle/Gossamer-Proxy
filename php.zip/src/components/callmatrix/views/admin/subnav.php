<ul class="subnav">
    <li>
        <a href="/admin/callmatrix/0/14">List Call Dates</a>
    </li>
    <li>
        <a href="/admin/callmatrix/calendar/0/14">View Calendar</a>
    </li>
</ul>