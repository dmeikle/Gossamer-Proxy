<ul class="subnav">
    <li>
        <a href="/admin/contact/0/20">List All ContactUs</a>
    </li>
    <li>
        <a href="/admin/contact/types/0/20">List All ContactUs Types</a>
    </li>  
    <li>
        <a href="/admin/contact/types/0">Create New ContactUs Type</a>
    </li>    
</ul>