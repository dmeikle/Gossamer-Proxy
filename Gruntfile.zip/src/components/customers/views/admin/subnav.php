<ul class='subnav'>
    <li>
        <a href="/admin/Customer/0/20">List all Customer</a>
    </li>
    <li>
        <a href="/admin/Customer/0">Add new contact</a>
    </li>
    <li>
        <a href="/admin/companies/0/20">List all companies</a>
    </li>
    <li>
        <a href="/admin/companies/0">Add new company</a>
    </li>
</ul>