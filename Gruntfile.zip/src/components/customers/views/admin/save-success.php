<h3>Save Success</h3>
<p>The Customer has been successfully saved</p>
<p><a href="/admin/Customer/0/20">Click here to continue</a></p>