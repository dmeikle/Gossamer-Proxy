welcome to the invitee page. you are successfully logged in.
<p>there should only be selections to acknowledge this page and the invitee should be ported into Customer table and 
    removed from the invitees table once we see if there are duplicates with the same email address or not. <br>
perhaps a "yes that is me" - we need to make sure an invitee's email does not already exist in the Customer table - 
if it does we can send a 'friend request' type of email to them where they can add them to their group instead</p>
<p>&nbsp;</p>