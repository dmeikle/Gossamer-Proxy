<ul class="subnav">
    <li><a href="/portal/Customer/list/0/20">View Customers</li>
    <li><a href="/portal/Customer/invites/0/20">View Invites List</a></li>
    <li><a href="/portal/Customer/invites/invite">Invite Someone</a></li>
</ul>