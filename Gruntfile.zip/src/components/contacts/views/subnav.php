<ul class="subnav">
    <li><a href="/portal/contacts/list/0/20">View Contacts</li>
    <li><a href="/portal/contacts/invites/0/20">View Invites List</a></li>
    <li><a href="/portal/contacts/invites/invite">Invite Someone</a></li>
</ul>