<h3>Save Success</h3>
<p>The Contact has been successfully saved</p>
<p><a href="/admin/contacts/0/20">Click here to continue</a></p>