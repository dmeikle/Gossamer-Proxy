<ul class='subnav'>
    <li>
        <a href="/admin/contacts/0/20">List all contacts</a>
    </li>
    <li>
        <a href="/admin/contacts/0">Add new contact</a>
    </li>
    <li>
        <a href="/admin/companies/0/20">List all companies</a>
    </li>
    <li>
        <a href="/admin/companies/0">Add new company</a>
    </li>
</ul>