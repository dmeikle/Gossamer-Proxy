<ul class="subnav">
    set permanent password (this will port them into the contacts table)
</ul>