<?php

return array(
        'LOGIN_FORM' => '登录表单',
	'LOGIN_EMAIL' => '电子邮件',
	'LOGIN_EMAIL_PROMPT' => '输入您的电子邮件地址',
	'LOGIN_PASSWORD' => '密码',
	'LOGIN_PASSWORD_PROMPT' => '输入您的密码',
	'LOGIN_LOST_PASSWORD' => '我忘记了密码',
	'LOGIN_SIGNIN' => '登入',
	'LOGIN_NEW' => '新?',
	'LOGIN_SIGNUP' => '报名',
	'LOGIN_STAY_LOGGED_IN' => '记住我的登录为一天'
);