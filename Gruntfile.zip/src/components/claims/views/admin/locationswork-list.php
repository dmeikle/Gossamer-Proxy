
<div style="text-align:right">Date: 2014-10-10</div>

<table class="table">     	  
    <thead>
        <tr>
     	    <th width="100">Area:</th>
     	    <th>Work Performed:</th>
   	</tr>
    </thead>
    <tr>
        <td>Entry</td>
        <td><div style="float:right" class="glyphicon glyphicon-pencil"></div>
            Remove Baseboard<br/>
            Remove Crown Moulding<br/>
            Remove Drywall<br/>
            Remove Insulation<br/>
            Place Dehumidifiers<br/>
            Place Blower Units
        </td>
    </tr>
    <tr>
        <td>Kitchen</td>
        <td>        
            Remove Baseboard<br/>
            Remove Crown Moulding<br/>
            Remove Drywall<br/>
            Remove Insulation<br/>
            Place Dehumidifiers<br/>
            Place Blower Units<br />
            Needs Carpenter to come in and remove wine rack
        </td>
    </tr>
    <tr>
        <td>Living Room</td>
        <td><div style="float:right" class="glyphicon glyphicon-pencil"></div>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </td>
    </tr>
    <tr>
        <td>Dining Room</td>
        <td><div style="float:right" class="glyphicon glyphicon-pencil"></div>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </td>
    </tr>
    <tr>
        <td>
            <select name="area">
                <option>Bathroom</option>
                <option>Hallway</option>
            </select></td>
        <td>
            <select class="form-control" multiple="multiple">
                <option>Remove Baseboard</option>
                <option>Remove Drywall</option>
                <option>Remove Insulation</option>
            </select>
            Notes:
            <textarea class="form-control"></textarea>
            
            
        </td>
    </tr>
    <tr>
        <td> </td>
        <td>
            <button class="btn btn-primary">Add Another</button> 
            <button class="btn btn-primary">Add and Go Back</button> 
            <button class="btn btn-primary">Cancel</button> 
        </td>
    </tr>
</table>