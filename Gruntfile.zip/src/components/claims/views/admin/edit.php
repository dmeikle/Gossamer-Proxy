


<form class="form-standard" role="form" method="post">
                <h2 class="form-signin-heading">new claim form</h2>
                <table class="table">
                	<tr>
                    	<td>Project Name</td>
                		<td><input class="form-control" placeholder="Project Name" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Property Manager</td>
                		<td><input class="form-control" placeholder="Property Manager" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Strata No:</td>
                		<td><input class="form-control" placeholder="Strata No" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Property MGMT Co:</td>
                		<td><input class="form-control" placeholder="Property MGMT Co" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Source Unit:</td>
                		<td><input class="form-control" placeholder="Source Unit" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Affected Units:</td>
                		<td><input class="form-control" placeholder="Affected Units" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Address:</td>
                		<td><input class="form-control" placeholder="Address" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>City:</td>
                		<td><input class="form-control" placeholder="City" name="dateReceived" type="text" /></td>
                    </tr>
                	<tr>
                    	<td>Phone/Fax/Cell:</td>
                		<td><input class="form-control" placeholder="Phone/Fax/Cell" name="dateReceived" type="text" /></td>
                    </tr>
                
                </table>
                	
                	<button class="btn btn-lg btn-primary btn-block" type="submit">Next</button>
              	</form>
