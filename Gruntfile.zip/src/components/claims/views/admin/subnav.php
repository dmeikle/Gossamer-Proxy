<ul class="subnav">
    <li>
        <a href="/admin/claims/0/20">List All Open</a>
    </li>
    <li>
        <a href="/admin/claim/1/0">Create New Claim</a>
    </li>
    <li>
        <a href="/admin/claims/scheduling/0/20">Scheduling</a>
    </li>    
</ul>