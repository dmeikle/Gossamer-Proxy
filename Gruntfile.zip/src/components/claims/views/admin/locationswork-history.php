
<table class="table table-striped">     	  
    <thead>
        <tr>
            <th>Date</th>
     	    <th>Phase</th>
     	    <th>Rooms</th>
            <th>Status</th>
   	</tr>
    </thead>
    <tr>
        <td>
            <table class="table" >
                <tr>
                    <td>2014-10-12</td>
                    <td>Scoping</td>
                    <td>Kitchen, Living Room, Dining Room</td>
                    <td>Waiting Estimate</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <table class="table">     	  
                            <thead>
                                <tr>
                                    <th width="100">Area:</th>
                                    <th>Work Performed:</th>
                                </tr>
                            </thead>
                            <tr>
                                <td>Entry</td>
                                <td>
                                    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
                                    The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here',
                                    making it look like readable English. </td>
                            </tr>
                            <tr>
                                <td>Kitchen</td>
                                <td>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </td>
                            </tr>
                            <tr>
                                <td>Living Room</td>
                                <td>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </td>
                            </tr>
                            <tr>
                                <td>Dining Room</td>
                                <td>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </td>
                            </tr>
                        </table
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td>2014-10-13</td>
        <td>Scoping</td>
        <td>Kitchen, Living Room, Dining Room</td>
        <td>Complete</td>
    </tr>
    <tr>
        <td>2014-10-13</td>
        <td>Construction</td>
        <td>Kitchen, Living Room, Dining Room</td>
        <td>Waiting approval</td>
    </tr>
    <tr>
        <td>2014-10-10</td>
        <td>Emergency</td>
        <td>Kitchen, Living Room, Dining Room</td>
        <td>In-progress</td>
    </tr>
    <tr>
        <td>2014-10-10</td>
        <td>Emergency</td>
        <td>Kitchen, Living Room, Dining Room</td>
        <td>In-progress</td>
    </tr>
    <tr>
        <td>2014-10-10</td>
        <td>Emergency</td>
        <td>Kitchen, Living Room, Dining Room</td>
        <td>In-progress</td>
    </tr>
</table>