

<div class="col-sm-6 col-md-3">
    <div class="c-widget c-widget-blank">
        <div class="profile-info">
             <h3>Icon List</h3>
        <p>This is a blank Widget. Use it to display small blurbs of information.</p>
        </div>
    </div>
</div>