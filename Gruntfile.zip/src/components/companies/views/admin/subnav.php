<ul class="subnav">
    <li>
        <a href="/admin/companies/0/20">List All Companies</a>
    </li>
    <li>
        <a href="/admin/companies/0">Add New Company</a>
    </li>    
</ul>