<table class="table">
  <tr>
      <td>Item</td>
      <td><input type="text" name="textfield" id="textfield"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Item not found? Enter here:<br>
    <input type="text" name="textfield3" id="textfield3"></td>
  </tr>
  <tr>
    <td>Quantity</td>
    <td><input type="text" name="textfield2" id="textfield2"></td>
  </tr>
  <tr>
    <td>Notes</td>
    <td><textarea name="textarea" id="textarea" cols="45" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><button class="btn">Save</button></td>
  </tr>
</table>
