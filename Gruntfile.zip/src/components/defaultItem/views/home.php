di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 
di mihi bonum faustum felixque se educerent, et domus mea. cum fiducia et laboro in me ipso, maiore in dies studio operam ut in certamen aliquando iuvare. 

<div id="newsfeed" style="width:200px;">
<?php
getcontent has been changed.
echo $this->getContent('website_blogs_feed', array(0,5));
?>
</div>