<?php

return array (
    'SECTION1' => 'We had a feng Shui master fly in from Shanghai for key office element layout and entrance positioning.',
    'SECTION2' => 'The stairwells we did grey slate to keep in the rustic feel then to blend in tone with the polished concrete floors as we transition to a more minimalist design ',
    'SECTION3' => 'Then the side doors we made without the doornails rivets but with the same lions head as guardians.',
    'SECTION4' => 'During the project the building was open for material transport to where the main doors with door rivet nails are now. Everyday looking at this opening it seemed so appropriate to make this a feature and center point to the building as time went by and make a statement of power and strength. ',
    'SECTION5' => 'The board room The Company’s western style café, I designed to have the bit of an industrial feel as there is nothing but factories in this area and compliments the exposed brick walls. What’s great about China is brick is used everywhere but I ask them not to cover it up as they typically trowel a grey coat mortar then white plaster coat. They say “but the walls won’t be finished” and I am “it’s the look we want of the old warehouses of the west and the retro feel we want”. ',
    'SECTION6' => 'This wood mosaic wall is made from recycled wood from China cargo ships that have finished their duty and lay to rest on shore. When I discovered it at a trade show, besides being so beautiful I thought very poignant in meaning to be used for this trading company’s office. We used it as a feature wall behind the reception desk. ',
    'SECTION7' => 'We made a water wall feature with slow running water, water is a fengshui (shui=water) element. The white glass hanging in the ceiling represent air (feng=air) and clouds which is a good fortune auspicious meaning. ',
    'SECTION8' => 'The wood reception desk and furniture is all custom made and I designed to keep minimal to allow the water wall and wood feature wall to stand out. We stained the furniture to be in the tone shades of the antique doors and wood feature wall. ',
    'SECTION9' => 'These doors were custom made on site and weigh over 400 pounds each and are over 10 feet high. This is one large and key element that brings the Asian feel to this design ',
    'SECTION10' => 'The LED lighting pattern is in the style of the fret border which represents and surrounds wealth. '
    );