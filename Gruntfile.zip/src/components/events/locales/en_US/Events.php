<?php

return array(
    'EVENT_COST' => 'Tickets',
    'EVENT_RSVP' => 'RSVP'   
);