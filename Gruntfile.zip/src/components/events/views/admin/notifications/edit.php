<h3>Event Notification Settings</h3>
here, you can add/remove recipients from the notification list.<br>
you can also specify notificationType (email, sms, telephone, etc..) 
for each recipient<br>
need an interface for this. questions:<br>
do we list all staff to select from?<br>
if so, is it a table or float left widgets style with image and
add/remove buttons?<br>
 <p>this is what data we are pulling from the 'already selected' table for now</p>
<?php

pr($EventNotifications);

?>

pagination is also available if needed here