<ul class="subnav">
    <li>
        <a href="/admin/events/0/20">List All Events</a>
    </li>
    <li>
        <a href="/admin/events/eventlocations/0/20">List All Event Locations</a>
    </li>
    <li>
        <a href="/admin/events/eventtypes/0/20">List All Event Types</a>
    </li>
    <li>
        <a href="/admin/events/eventcontacts/0/20">List All Event Contacts</a>
    </li>
    <li>
        <a href="/admin/events/eventprospects/0/20">List All Event Prospects</a>
    </li>
    <li>
        <a href="/admin/events/lists/0/20">List All Invite Lists</a>
    </li>
</ul>

<!--
<ul class="subnav">
    <li>
        <a href="/admin/scheduling/compressed/1/20141015">Compressed View</a>
    </li>
    <li>
        <a href="/admin/scheduling/chart/1/20141015">Chart View</a>
    </li>
    <li>
        <a href="/admin/scheduling/calendar/1/20141015">Calendar View</a>
    </li>
</ul>
-->