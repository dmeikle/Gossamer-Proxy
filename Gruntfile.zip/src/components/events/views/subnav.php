<ul class="subnav">
    <li>
        <a href="/portal/events/0/20">List View</a>
    </li>
    <li>
        <a href="">Chart View</a>
    </li>
    <li>
        <a href="">Calendar View</a>
    </li>
</ul>