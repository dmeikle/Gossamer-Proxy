<?php

namespace config;

interface ConfigurationInterface
{
    
}
